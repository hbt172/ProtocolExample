//
//  ViewController.swift
//  ProtocolExample
//
//  Created by Nirav Joshi on 08/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

class ViewController: UIViewController,PassDataDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func btnSecondClick(_ sender: Any) {
        let objstoryborad = UIStoryboard.init(name: "Main", bundle: Bundle.main)
        let objVC = objstoryborad.instantiateViewController(withIdentifier: "SecondVC") as! SecondVC
        objVC.delegate = self
        self.navigationController?.pushViewController(objVC, animated: true)
    }
    
    func StringPass(StrName: String) {
        print(StrName)
        print(String(data: "Hello 😃.".data(using: String.Encoding.nonLossyASCII, allowLossyConversion: true)!, encoding: String.Encoding.utf8) as Any)
        
        
    }
    
}

