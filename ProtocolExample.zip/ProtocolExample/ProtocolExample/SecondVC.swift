//
//  SecondVC.swift
//  ProtocolExample
//
//  Created by Nirav Joshi on 08/10/18.
//  Copyright © 2018 Nirav Joshi. All rights reserved.
//

import UIKit

protocol PassDataDelegate {
    func StringPass(StrName : String)
}

class SecondVC: UIViewController {
    var delegate : PassDataDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnFirstClick(_ sender: Any) {
        delegate?.StringPass(StrName: "Hardik Talaviya")
    }
    

}
